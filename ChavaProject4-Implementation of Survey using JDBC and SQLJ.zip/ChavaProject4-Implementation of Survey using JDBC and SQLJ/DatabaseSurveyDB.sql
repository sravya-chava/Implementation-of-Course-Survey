use SurveyDB;

create table UserDetails(
	userId int PRIMARY KEY IDENTITY(1,1),
	userName varchar(20),
	userPassWord varchar(20),
	userGroup varchar(20)
)
create table Survey(
	surveyId int PRIMARY KEY IDENTITY(1,1),
	courseId varchar(20),
	userId varchar(20),
	taId int,
	fAndAId int,
	rAndAId int,
	aAndqId int,
	oAndeId int,
	sAndsAndeId int,
	sAndiId int
)
create table Student(
int sid PRIMARY KEY IDENTITY(1,1);
sLname varchar(20),
sFname varchar(20),
gradelevel varchar(20)
);
create table TeachingAproaches(
	taId int PRIMARY KEY IDENTITY(1,1),
	ta1st varchar(20),
	ta2nd varchar(20),
	ta3rd varchar(20),
	ta4th varchar(20),
	ta5th varchar(20),
	ta6th varchar(20),
	ta7th varchar(20),
	ta8th varchar(20),
	ta9th varchar(20),
	ta10th varchar(20),
	tacomment varchar(20)
)
use SurveyDB;
create table FeedbackAssesment(
	fAndAId int PRIMARY KEY IDENTITY(1,1),
	fa1st varchar(20),
	fa2nd varchar(20),
	fa3rd varchar(20),
	facomment varchar(20),
)
create table ResourceAdministration(
	rAndAId int PRIMARY KEY IDENTITY(1,1),
	ra1st varchar(20),
	ra2nd varchar(20),
	ra3rd varchar(20),
	racomment varchar(20),
)
create table AditionalQuestions(
	aAndqId int PRIMARY KEY IDENTITY(1,1),
	aq1st varchar(20),
	aq2nd varchar(20),
	aq3rd varchar(20),
	aq4th varchar(20),
	aq5th varchar(20),
	aqcomment varchar(20),
)
create table OverallExperience(
	oAndeId int PRIMARY KEY IDENTITY(1,1),
	oe1st varchar(20),
	oe2nd varchar(20),
	oe3rd varchar(20),
	oe4th varchar(20),
	oecomment varchar(20),
)
create table StudentSelfEvaluation(
	sAndsAndeId int PRIMARY KEY IDENTITY(1,1),
	se1st varchar(20),
	se2nd varchar(20),
	ssecomment varchar(20),
)
create table StrengthAndImprovement(
	sAndiId int PRIMARY KEY IDENTITY(1,1),
	sicomment1 varchar(20),
	sicomment2 varchar(20),
	sicomment3 varchar(20),
	sicomment4 varchar(20),
)

create table Instructor(
instructorId int PRIMARY KEY,
instructorName varchar(20)
);

create table Course(
courseId int PRIMARY KEY,
instructorId int REFERENCES Instructor(instructorId)
                        ON UPDATE CASCADE
						ON DELETE CASCADE,
courseSection varchar(20),
courseName varchar(20),
courseTermYear varchar(20),
);

create table Survey(
surveyId int PRIMARY KEY IDENTITY(1,1),
courseId int FOREIGN KEY REFERENCES Course(courseId)
                        ON UPDATE CASCADE
						ON DELETE CASCADE,
userId int FOREIGN KEY REFERENCES UserDetails(userId)
                        ON UPDATE CASCADE
						ON DELETE CASCADE,
);


select * from UserDetails;
