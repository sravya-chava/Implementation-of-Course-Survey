/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.survey.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;


/**
 *
 * @author Chava
 */
@ManagedBean(name="db")
public class database {
    String url="jdbc:sqlserver://localhost;databaseName=SurveyDB;integratedSecurity=true";
    Connection connection;
    ResultSet rs= null;
    ResultSet rs1= null;
    ResultSet rs2= null;
    ResultSet rs3= null;
    ResultSet rs4= null;
    ResultSet rs5= null;
    PreparedStatement ps= null;
    PreparedStatement ps1= null; 
    PreparedStatement ps2= null;
    PreparedStatement ps3= null;
    PreparedStatement ps4= null; 
    Statement stmt; 
    Student newStudent;
    String selectUser;
    String createUser;
    String insertUser;
    public String userName;
    public String passWord;
    public String returnPage;
    public String invalidMessage;
    public int msgFlag;
    public int status;
    public String userGroup;
    
    public String getUserGroup() {
        return userGroup;
    }

    public int getMsgFlag() {
        return msgFlag;
    }

    public void setMsgFlag(int msgFlag) {
        this.msgFlag = msgFlag;
    }

    public void setUserGroup(String userGroup) {
        this.userGroup = userGroup;
    }
   
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }
    public void ConncetionFucntion(){
    try {
             Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
             connection = DriverManager.getConnection(url);
             System.out.println("Connection successfull");
             stmt= connection.createStatement();
             
        } 
        catch (Exception ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
    public String loginValidation(){
        selectUser = ("select userPassWord,userGroup from UserDetails where userName = ?");
        try {
            ConncetionFucntion();
            ps=connection.prepareStatement(selectUser);
            System.out.println("user name is " + userName);
            ps.setString(1, userName);
            rs=ps.executeQuery();
            while(rs.next()){
            if(rs.getString(1).equalsIgnoreCase(passWord))
            {
                if("student".equals(rs.getString("userGroup")))
                returnPage = "Survey";
                else
                returnPage = "instructor";
            }
            else
            {
                msgFlag = 1;
                invalidMessage = "Invalid Password !!Try Again";
                returnPage = "index";
            }
        }
   } 
            catch (SQLException ex) {
                 Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
            }
            return returnPage;
    }
    public String courseDetails(Student stud1){
       String insertCourse = ("insert into Course (courseId,courseName,courseTermYear) values (1,?,?)");
        try {
            ConncetionFucntion();
            ps=connection.prepareStatement(insertCourse);
            ps.setString(1,stud1.courseName);        
            ps.setString(2,stud1.termAndYear);
            status = ps.executeUpdate();
            if(status == 1)
                returnPage = "Survey2";
            else
                returnPage = "Survey";
            } 
            catch (SQLException ex) {
                 Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
            }
            return returnPage;
    }
    public String instructorDetails(Student stud1){
       String insertInstructor = ("insert into Instructor (instructorName) values (?)");
        try {
            ConncetionFucntion();
            ps=connection.prepareStatement(insertInstructor);
            ps.setString(1,stud1.courseInstructor);        
            status = ps.executeUpdate();
            if(status == 1)
                returnPage = "Survey2";
            else
                returnPage = "Survey";
            } 
            catch (SQLException ex) {
                 Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
            }
            return returnPage;
    }
    
    public String teachingAproachAction(Student stud1) throws SQLException {
    try
    {
       ConncetionFucntion();
       String teachingQuery = "insert into TeachingAproaches values (?,?,?,?,?,?,?,?,?,?,?)";
       ps = connection.prepareStatement(teachingQuery);
       ps.setString(1,stud1.interest);        
       ps.setString(2,stud1.time);
       ps.setString(3,stud1.organisation);
       ps.setString(4,stud1.encouragement);
       ps.setString(5,stud1.indepth);
       ps.setString(6,stud1.appeared);
       ps.setString(7,stud1.methods);
       ps.setString(8,stud1.challenges);
       ps.setString(9,stud1.outbox);
       ps.setString(10,stud1.active);
       ps.setString(11,stud1.teachingComments);
       status = ps.executeUpdate();
       if(status == 1)
           returnPage = "Survey2";
       else
           returnPage = "Survey";
    }
    catch(Exception ex){
        System.out.println("Exception in addSurvey:-");
        ex.printStackTrace();
    }   
    return returnPage;
    }
    public String FeedbackAssessmentAction(Student stud1) throws SQLException {
    try
    {
       ConncetionFucntion();
       String feedbackQuery = "insert into FeedbackAssesment values (?,?,?,?)";
       ps = connection.prepareStatement(feedbackQuery);
       ps.setString(1,stud1.clarity);        
       ps.setString(2,stud1.timeFrame);
       ps.setString(3,stud1.improvement);
       ps.setString(4,stud1.teachingassessment);
       status = ps.executeUpdate();
       if(status == 1)
           returnPage = "Survey3";
       else
           returnPage = "Survey";
    }
    catch(Exception ex){
        System.out.println("Exception in addSurvey:-");
        ex.printStackTrace();
    }   
    return returnPage;
    }
    public String ResourceAndAdministrationAction(Student stud1) throws SQLException {
    try
    {
       ConncetionFucntion();
       String feedbackQuery = "insert into ResourceAdministration values (?,?,?,?)";
       ps = connection.prepareStatement(feedbackQuery);
       ps.setString(1,stud1.support);        
       ps.setString(2,stud1.bbresources);
       ps.setString(3,stud1.guidance);
       ps.setString(4,stud1.resourceAdmin);
       status = ps.executeUpdate();
       if(status == 1)
           returnPage = "Survey3";
       else
           returnPage = "Survey";
    }
    catch(Exception ex){
        System.out.println("Exception in addSurvey:-");
        ex.printStackTrace();
    }   
    return returnPage;
    }
    public String AditionalQuestionsAction(Student stud1) throws SQLException {
    try
    {
       ConncetionFucntion();
       String feedbackQuery = "insert into AditionalQuestions values (?,?,?,?,?,?)";
       ps = connection.prepareStatement(feedbackQuery);
       ps.setString(1,stud1.explanation);        
       ps.setString(2,stud1.outline);
       ps.setString(3,stud1.grading);
       ps.setString(4,stud1.exams);
       ps.setString(5,stud1.projects);
       ps.setString(6,stud1.additionalComments);
       status = ps.executeUpdate();
       if(status == 1)
           returnPage = "Survey3";
       else
           returnPage = "Survey";
    }
    catch(Exception ex){
        System.out.println("Exception in addSurvey:-");
        ex.printStackTrace();
    }   
    return returnPage;
    }
    public String OverallExperienceAction(Student stud1) throws SQLException {
    try
    {
       ConncetionFucntion();
       String feedbackQuery = "insert into OverallExperience values (?,?,?,?,?)";
       ps = connection.prepareStatement(feedbackQuery);
       ps.setString(1,stud1.worthness);        
       ps.setString(2,stud1.recommendation);
       ps.setString(3,stud1.experience);
       ps.setString(4,stud1.homeworks);
       ps.setString(5,stud1.overallExperience);
       status = ps.executeUpdate();
       if(status == 1)
           returnPage = "Survey3";
       else
           returnPage = "Survey";
    }
    catch(Exception ex){
        System.out.println("Exception in addSurvey:-");
        ex.printStackTrace();
    }   
    return returnPage;
    }
    public String StudentSelfEvaluationAction(Student stud1) throws SQLException {
    try
    {
       ConncetionFucntion();
       String feedbackQuery = "insert into StudentSelfEvaluation values (?,?,?)";
       ps = connection.prepareStatement(feedbackQuery);
       ps.setString(1,stud1.constructive);        
       ps.setString(2,stud1.outcome);
       ps.setString(3,stud1.selfEvaluation);
       status = ps.executeUpdate();
       if(status == 1)
           returnPage = "Survey3";
       else
           returnPage = "Survey";
    }
    catch(Exception ex){
        System.out.println("Exception in addSurvey:-");
        ex.printStackTrace();
    }   
    return returnPage;
    }
    public String StrengthAndImprovementAction(Student stud1) throws SQLException {
    try
    {
       ConncetionFucntion();
       String feedbackQuery = "insert into StrengthAndImprovement values (?,?,?,?)";
       ps = connection.prepareStatement(feedbackQuery);
       ps.setString(1,stud1.selfEvaluation1);        
       ps.setString(2,stud1.selfEvaluation2);
       ps.setString(3,stud1.selfEvaluation3);
       ps.setString(4,stud1.selfEvaluation4);
       status = ps.executeUpdate();
       if(status == 1)
           returnPage = "Survey4";
       else
           returnPage = "Survey";
    }
    catch(Exception ex){
        System.out.println("Exception in addSurvey:-");
        ex.printStackTrace();
    }   
    return returnPage;
    }
/////////////////////////////////////Instructor//////////////////////
    public ArrayList<String> get_courses()
    {
        ConncetionFucntion();
        ArrayList<String> courseIdList = new ArrayList<String>(); 
        try{
            ps=connection.prepareStatement("select courseName from Course");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
               courseIdList.add(rs.getString("courseName"));
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return courseIdList;
    }
    public ArrayList<String> get_courseIds()
    {
        ConncetionFucntion();
        ArrayList<String> courseList = new ArrayList<String>(); 
        try{
            ps=connection.prepareStatement("select courseId from Course");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
               courseList.add(rs.getString("courseId"));
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        return courseList;
    }
    public void surveyTabletid(Student stu1)
    {
        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("select MAX(taid) from TeachingAproaches");
            ResultSet rs = ps.executeQuery();
           while(rs.next()){
            String taid = rs.getString(1);
            System.out.println("tid is " + taid);
            String tidQuery = "insert into Survey(courseId,taid) values(?,?)";
            ps = connection.prepareStatement(tidQuery);
            ps.setString(1,stu1.courseId);
            ps.setString(2,taid);        
            status = ps.executeUpdate();
            System.out.println("status is " + status);
            if(status == 1)
                returnPage = "Survey3";
            else
                returnPage = "Survey"; 
             }
        }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }   
public void surveyTablefAndAId(Student stu1)
    {
        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("select MAX(fAndAId) from FeedbackAssesment");
            ResultSet rs = ps.executeQuery();
           while(rs.next()){
            String fAndAId = rs.getString(1);
            String FeedbackAssesmentQuery = "insert into Survey(courseId,fAndAId) values(?,?)";
            ps = connection.prepareStatement(FeedbackAssesmentQuery);
            ps.setString(1,stu1.courseId);        
            ps.setString(2,fAndAId);        
            status = ps.executeUpdate();
            System.out.println("status is " + status);
            if(status == 1)
                returnPage = "Survey3";
            else
                returnPage = "Survey"; 
             }
        }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
public void surveyTablerAndAId(Student stu1)
    {
        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("select MAX(rAndAId) from ResourceAdministration");
            ResultSet rs = ps.executeQuery();
           while(rs.next()){
            String rAndAId = rs.getString(1);
            System.out.println("tid is " + rAndAId);
            String tidQuery = "insert into Survey(courseId,rAndAId) values(?,?)";
            ps = connection.prepareStatement(tidQuery);
            ps.setString(1,stu1.courseId);        
            ps.setString(2,rAndAId);        
            status = ps.executeUpdate();
            System.out.println("status is " + status);
            if(status == 1)
                returnPage = "Survey3";
            else
                returnPage = "Survey"; 
             }
        }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }   
public void surveyTableaAndqId(Student stu1)
    {
        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("select MAX(taid) from AditionalQuestions");
            ResultSet rs = ps.executeQuery();
           while(rs.next()){
            String aAndqId = rs.getString(1);
            System.out.println("tid is " + aAndqId);
            String tidQuery = "insert into Survey(courseId,aAndqId) values(?,?)";
            ps = connection.prepareStatement(tidQuery);
            ps.setString(1,stu1.courseId); 
            ps.setString(2,aAndqId);        
            status = ps.executeUpdate();
            System.out.println("status is " + status);
            if(status == 1)
                returnPage = "Survey3";
            else
                returnPage = "Survey"; 
             }
        }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }   
public void surveyTableoAndeId(Student stu1)
    {
        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("select MAX(oAndeId) from OverallExperience");
            ResultSet rs = ps.executeQuery();
           while(rs.next()){
            String oAndeId = rs.getString(1);
            System.out.println("tid is " + oAndeId);
            String tidQuery = "insert into Survey(courseId,oAndeId) values(?,?)";
            ps = connection.prepareStatement(tidQuery);
            ps.setString(1,stu1.courseId);        
            ps.setString(2,oAndeId);        
            status = ps.executeUpdate();
            System.out.println("status is " + status);
            if(status == 1)
                returnPage = "Survey3";
            else
                returnPage = "Survey"; 
             }
        }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }   
public void surveyTablesAndsAndeId(Student stu1)
    {
        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("select MAX(taid) from StudentSelfEvaluation");
            ResultSet rs = ps.executeQuery();
           while(rs.next()){
            String sAndsAndeId = rs.getString(1);
            System.out.println("tid is " + sAndsAndeId);
            String tidQuery = "insert into Survey(courseId,sAndsAndeId) values(?,?)";
            ps = connection.prepareStatement(tidQuery);
            ps.setString(1,stu1.courseId);        
            ps.setString(2,sAndsAndeId);        
            status = ps.executeUpdate();
            System.out.println("status is " + status);
            if(status == 1)
                returnPage = "Survey3";
            else
                returnPage = "Survey"; 
             }
        }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
public void surveyTablesAndiId(Student stu1)
    {
        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("select MAX(sAndiId) from StrengthAndImprovement");
            ResultSet rs = ps.executeQuery();
           while(rs.next()){
            String sAndiId = rs.getString(1);
            System.out.println("tid is " + sAndiId);
            String tidQuery = "insert into Survey(courseId,sAndiId) values(?,?)";
            ps = connection.prepareStatement(tidQuery);
            ps.setString(1,stu1.courseId);
            ps.setString(2,sAndiId);        
            status = ps.executeUpdate();
            System.out.println("status is " + status);
            if(status == 1)
                returnPage = "Survey3";
            else
                returnPage = "Survey"; 
             }
        }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   public ArrayList<String> surveyAverageinterest()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ta1st) as first from TeachingAproaches where ta1st='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(ta1st) as first from TeachingAproaches where ta1st='Agree'");
            ps2=connection.prepareStatement("SELECT count(ta1st) as first from TeachingAproaches where ta1st='Neutral'");
            ps3=connection.prepareStatement("SELECT count(ta1st) as first from TeachingAproaches where ta1st='Disagree'");
            ps4=connection.prepareStatement("SELECT count(ta1st) as first from TeachingAproaches where ta1st='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
   public ArrayList<String> surveyAveragetime()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ta2nd) as first from TeachingAproaches where ta2nd='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(ta2nd) as first from TeachingAproaches where ta2nd='Agree'");
            ps2=connection.prepareStatement("SELECT count(ta2nd) as first from TeachingAproaches where ta2nd='Neutral'");
            ps3=connection.prepareStatement("SELECT count(ta2nd) as first from TeachingAproaches where ta2nd='Disagree'");
            ps4=connection.prepareStatement("SELECT count(ta2nd) as first from TeachingAproaches where ta2nd='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
   public ArrayList<String> surveyAverageorganisation()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ta3rd) as first from TeachingAproaches where ta3rd='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(ta3rd) as first from TeachingAproaches where ta3rd='Agree'");
            ps2=connection.prepareStatement("SELECT count(ta3rd) as first from TeachingAproaches where ta3rd='Neutral'");
            ps3=connection.prepareStatement("SELECT count(ta3rd) as first from TeachingAproaches where ta3rd='Disagree'");
            ps4=connection.prepareStatement("SELECT count(ta3rd) as first from TeachingAproaches where ta3rd='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
   
  public ArrayList<String> surveyAverageencouragement()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ta4th) as first from TeachingAproaches where ta4th='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(ta4th) as first from TeachingAproaches where ta4th='Agree'");
            ps2=connection.prepareStatement("SELECT count(ta4th) as first from TeachingAproaches where ta4th='Neutral'");
            ps3=connection.prepareStatement("SELECT count(ta4th) as first from TeachingAproaches where ta4th='Disagree'");
            ps4=connection.prepareStatement("SELECT count(ta4th) as first from TeachingAproaches where ta4th='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
  public ArrayList<String> surveyAverageindepth()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ta5th) as first from TeachingAproaches where ta5th='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(ta5th) as first from TeachingAproaches where ta5th='Agree'");
            ps2=connection.prepareStatement("SELECT count(ta5th) as first from TeachingAproaches where ta5th='Neutral'");
            ps3=connection.prepareStatement("SELECT count(ta5th) as first from TeachingAproaches where ta5th='Disagree'");
            ps4=connection.prepareStatement("SELECT count(ta5th) as first from TeachingAproaches where ta5th='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
  public ArrayList<String> surveyAverageappeared()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ta6th) as first from TeachingAproaches where ta6th='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(ta6th) as first from TeachingAproaches where ta6th='Agree'");
            ps2=connection.prepareStatement("SELECT count(ta6th) as first from TeachingAproaches where ta6th='Neutral'");
            ps3=connection.prepareStatement("SELECT count(ta6th) as first from TeachingAproaches where ta6th='Disagree'");
            ps4=connection.prepareStatement("SELECT count(ta6th) as first from TeachingAproaches where ta6th='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
  public ArrayList<String> surveyAveragemethods()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ta7th) as first from TeachingAproaches where ta7th='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(ta7th) as first from TeachingAproaches where ta7th='Agree'");
            ps2=connection.prepareStatement("SELECT count(ta7th) as first from TeachingAproaches where ta7th='Neutral'");
            ps3=connection.prepareStatement("SELECT count(ta7th) as first from TeachingAproaches where ta7th='Disagree'");
            ps4=connection.prepareStatement("SELECT count(ta7th) as first from TeachingAproaches where ta7th='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

           while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
  public ArrayList<String> surveyAveragechallenges()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ta8th) as first from TeachingAproaches where ta8th='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(ta8th) as first from TeachingAproaches where ta8th='Agree'");
            ps2=connection.prepareStatement("SELECT count(ta8th) as first from TeachingAproaches where ta8th='Neutral'");
            ps3=connection.prepareStatement("SELECT count(ta8th) as first from TeachingAproaches where ta8th='Disagree'");
            ps4=connection.prepareStatement("SELECT count(ta8th) as first from TeachingAproaches where ta8th='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
  public ArrayList<String> surveyAverageoutbox()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ta9th) as first from TeachingAproaches where ta9th='Yes'");
            ps1=connection.prepareStatement("SELECT count(ta9th) as first from TeachingAproaches where ta9th='No'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            while(rs.next()){
            dummysurvey.add("Yes "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("No "+rs1.getString("first"));
            }
        }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageactive()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ta10th) as first from TeachingAproaches where ta10th='Yes'");
            ps1=connection.prepareStatement("SELECT count(ta10th) as first from TeachingAproaches where ta10th='No'");
            
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
           
            while(rs.next()){
            dummysurvey.add("Yes "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("No "+rs1.getString("first"));
            }
            
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAveragetacomments()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT tacomment as first from TeachingAproaches");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
            dummysurvey.add("Comments are "+rs.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    //////////////////////////////
    public ArrayList<String> surveyAverageclarity()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(fa1st) as first from FeedbackAssesment where fa1st='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(fa1st) as first from FeedbackAssesment where fa1st='Agree'");
            ps2=connection.prepareStatement("SELECT count(fa1st) as first from FeedbackAssesment where fa1st='Neutral'");
            ps3=connection.prepareStatement("SELECT count(fa1st) as first from FeedbackAssesment where fa1st='Disagree'");
            ps4=connection.prepareStatement("SELECT count(fa1st) as first from FeedbackAssesment where fa1st='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAveragetimeFrame()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(fa2nd) as first from FeedbackAssesment where fa2nd='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(fa2nd) as first from FeedbackAssesment where fa2nd='Agree'");
            ps2=connection.prepareStatement("SELECT count(fa2nd) as first from FeedbackAssesment where fa2nd='Neutral'");
            ps3=connection.prepareStatement("SELECT count(fa2nd) as first from FeedbackAssesment where fa2nd='Disagree'");
            ps4=connection.prepareStatement("SELECT count(fa2nd) as first from FeedbackAssesment where fa2nd='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageimprovement()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(fa3rd) as first from TeachingAproaches where fa3rd='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(fa3rd) as first from TeachingAproaches where fa3rd='Agree'");
            ps2=connection.prepareStatement("SELECT count(fa3rd) as first from TeachingAproaches where fa3rd='Neutral'");
            ps3=connection.prepareStatement("SELECT count(fa3rd) as first from TeachingAproaches where fa3rd='Disagree'");
            ps4=connection.prepareStatement("SELECT count(fa3rd) as first from TeachingAproaches where fa3rd='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageteachingassessment()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT facomment as first from FeedbackAssesment");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
            dummysurvey.add("Comments are "+rs.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }

////////////////////////////////////////
public ArrayList<String> surveyAveragesupport()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ra1st) as first from ResourceAdministration where ra1st='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(ra1st) as first from ResourceAdministration where ra1st='Agree'");
            ps2=connection.prepareStatement("SELECT count(ra1st) as first from ResourceAdministration where ra1st='Neutral'");
            ps3=connection.prepareStatement("SELECT count(ra1st) as first from ResourceAdministration where ra1st='Disagree'");
            ps4=connection.prepareStatement("SELECT count(ra1st) as first from ResourceAdministration where ra1st='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
public ArrayList<String> surveyAveragebbresources()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ra2nd) as first from ResourceAdministration where ra2nd='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(ra2nd) as first from ResourceAdministration where ra2nd='Agree'");
            ps2=connection.prepareStatement("SELECT count(ra2nd) as first from ResourceAdministration where ra2nd='Neutral'");
            ps3=connection.prepareStatement("SELECT count(ra2nd) as first from ResourceAdministration where ra2nd='Disagree'");
            ps4=connection.prepareStatement("SELECT count(ra2nd) as first from ResourceAdministration where ra2nd='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
public ArrayList<String> surveyAverageguidance()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(ra3rd) as first from ResourceAdministration where ra3rd='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(ra3rd) as first from ResourceAdministration where ra3rd='Agree'");
            ps2=connection.prepareStatement("SELECT count(ra3rd) as first from ResourceAdministration where ra3rd='Neutral'");
            ps3=connection.prepareStatement("SELECT count(ra3rd) as first from ResourceAdministration where ra3rd='Disagree'");
            ps4=connection.prepareStatement("SELECT count(ra3rd) as first from ResourceAdministration where ra3rd='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageresourceAdmin()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT racomment as first from ResourceAdministration");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
            dummysurvey.add("Comments are "+rs.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    //////////////////////////////////////////////////////
    public ArrayList<String> surveyAverageoutline()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(aq2nd) as first from AditionalQuestions where aq2nd='Yes'");
            ps1=connection.prepareStatement("SELECT count(aq2nd) as first from AditionalQuestions where aq2nd='No'");
            
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
           
            while(rs.next()){
            dummysurvey.add("Yes "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("No "+rs1.getString("first"));
            }
            
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageexplanation()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(aq1st) as first from AditionalQuestions where aq1st='Yes'");
            ps1=connection.prepareStatement("SELECT count(aq1st) as first from AditionalQuestions where aq1st='No'");
            
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
           
            while(rs.next()){
            dummysurvey.add("Yes "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("No "+rs1.getString("first"));
            }
            
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAveragegrading()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(aq3rd) as first from AditionalQuestions where aq3rd='Yes'");
            ps1=connection.prepareStatement("SELECT count(aq3rd) as first from AditionalQuestions where aq3rd='No'");
            
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
           
            while(rs.next()){
            dummysurvey.add("Yes "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("No "+rs1.getString("first"));
            }
            
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageexams()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(aq4th) as first from AditionalQuestions where aq4th='Yes'");
            ps1=connection.prepareStatement("SELECT count(aq4th) as first from AditionalQuestions where aq4th='No'");
            
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
           
            while(rs.next()){
            dummysurvey.add("Yes "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("No "+rs1.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageprojects()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(aq5th) as first from AditionalQuestions where aq5th='Yes'");
            ps1=connection.prepareStatement("SELECT count(aq5th) as first from AditionalQuestions where aq5th='No'");
            
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
           
            while(rs.next()){
            dummysurvey.add("Yes "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("No "+rs1.getString("first"));
            }
            
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageadditionalcomments()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT aqcomment as first from AditionalQuestions");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
            dummysurvey.add("Comments are "+rs.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    //////////////
    public ArrayList<String> surveyAverageworthness()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(oe1st) as first from OverallExperience where oe1st='Yes'");
            ps1=connection.prepareStatement("SELECT count(oe1st) as first from OverallExperience where oe1st='No'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            while(rs.next()){
            dummysurvey.add("Yes "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("No "+rs1.getString("first"));
            }
        }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAveragerecommendation()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(oe2nd) as first from OverallExperience where oe2nd='Yes'");
            ps1=connection.prepareStatement("SELECT count(oe2nd) as first from OverallExperience where oe2nd='No'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            while(rs.next()){
            dummysurvey.add("Yes "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("No "+rs1.getString("first"));
            }
        }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageexperience()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(oe3rd) as first from OverallExperience where oe3rd='Excellent'");
            ps1=connection.prepareStatement("SELECT count(oe3rd) as first from OverallExperience where oe3rd='Very Good'");
            ps2=connection.prepareStatement("SELECT count(oe3rd) as first from OverallExperience where oe3rd='Good'");
            ps3=connection.prepareStatement("SELECT count(oe3rd) as first from OverallExperience where oe3rd='Fair'");
            ps4=connection.prepareStatement("SELECT count(oe3rd) as first from OverallExperience where oe3rd='Poor'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Excellent "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Very Good "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Good "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Fair "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Poor "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAveragehomeworks()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(oe4th) as first from OverallExperience where oe4th='0-4h'");
            ps1=connection.prepareStatement("SELECT count(oe4th) as first from OverallExperience where oe4th='5-8h'");
            ps2=connection.prepareStatement("SELECT count(oe4th) as first from OverallExperience where oe4th='9-12h'");
            ps3=connection.prepareStatement("SELECT count(oe4th) as first from OverallExperience where oe4th='12-16h'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();

            while(rs.next()){
            dummysurvey.add("0-4h "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("5-8h "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("9-12h "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("12-16h "+rs3.getString("first"));
            }
            
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageoverallExperience()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT oecomment as first from OverallExperience");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
            dummysurvey.add(rs.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    /////////////////////////
    public ArrayList<String> surveyAverageconstructive()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(se1st) as first from StudentSelfEvaluation where se1st='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(se1st) as first from StudentSelfEvaluation where se1st='Agree'");
            ps2=connection.prepareStatement("SELECT count(se1st) as first from StudentSelfEvaluation where se1st='Neutral'");
            ps3=connection.prepareStatement("SELECT count(se1st) as first from StudentSelfEvaluation where se1st='Disagree'");
            ps4=connection.prepareStatement("SELECT count(se1st) as first from StudentSelfEvaluation where se1st='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageoveralloutcome()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT count(se2nd) as first from StudentSelfEvaluation where se2nd='Strongly Agree'");
            ps1=connection.prepareStatement("SELECT count(se2nd) as first from StudentSelfEvaluation where se2nd='Agree'");
            ps2=connection.prepareStatement("SELECT count(se2nd) as first from StudentSelfEvaluation where se2nd='Neutral'");
            ps3=connection.prepareStatement("SELECT count(se2nd) as first from StudentSelfEvaluation where se2nd='Disagree'");
            ps4=connection.prepareStatement("SELECT count(se2nd) as first from StudentSelfEvaluation where se2nd='Strongly Disagree'");
            ResultSet rs = ps.executeQuery();
            ResultSet rs1 = ps1.executeQuery();
            ResultSet rs2 = ps2.executeQuery();
            ResultSet rs3 = ps3.executeQuery();
            ResultSet rs4 = ps4.executeQuery();

            while(rs.next()){
            dummysurvey.add("Strongly Agree "+rs.getString("first"));
            }
            while(rs1.next()){
            dummysurvey.add("Agree "+rs1.getString("first"));
            }
            while(rs2.next()){
            dummysurvey.add("Neutral "+rs2.getString("first"));
            }
            while(rs3.next()){
            dummysurvey.add("Disagree "+rs3.getString("first"));
            }
            while(rs4.next()){
            dummysurvey.add("Strongly DisAgree "+rs4.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
     public ArrayList<String> surveyAverageselfEvaluation()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT ssecomment as first from StudentSelfEvaluation");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
            dummysurvey.add(rs.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
   
    ///////////////////////////
    public ArrayList<String> surveyAverageselfEvaluation1()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT sicomment1 as first from StrengthAndImprovement");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
            dummysurvey.add(rs.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageselfEvaluation2()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT sicomment2 as first from StrengthAndImprovement");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
            dummysurvey.add(rs.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageselfEvaluation3()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT sicomment3 as first from StrengthAndImprovement");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
            dummysurvey.add(rs.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    public ArrayList<String> surveyAverageselfEvaluation4()
    {
       ArrayList<String> dummysurvey = new ArrayList<String>(); 

        ConncetionFucntion();
        try{
            ps=connection.prepareStatement("SELECT sicomment4 as first from StrengthAndImprovement");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
            dummysurvey.add(rs.getString("first"));
            }
           }
        catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("interest array is"+dummysurvey);
        return dummysurvey;
    }
    
}