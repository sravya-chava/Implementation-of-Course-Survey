/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.survey.model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Chava
 */
@ManagedBean(name="stu")
@SessionScoped
public class Student {
      
   
    private String userName;
    private String passWord;
    public String courseName;
    public String courseInstructor;
    public String termAndYear;
    public String interest;
    public String time;
    public String organisation;
    public String encouragement;
    public String indepth;
    public String methods;
    public String appeared;
    public String challenges;
    public String outbox;
    public String active;
    public String clarity;
    public String resources;
    public String teachingComments;
    public String resourceAdmin;
    public String fbackAssessment;
    public String improvement;
    public String additionalComments;
    public String guidance;
    public String support;
    public String bbresources;
    public String timeFrame;
    public String outcome;
    public String constructive;
    public String explanation;
    public String grading;
    public String homeworks;
    public String recommendation;
    public String outline;
    public String exams;
    public String projects;
    public String worthness;
    public String experience;
    public String overallExperience;
    public String selfEvaluation;
    public String teachingassessment;
    public String selfEvaluation1;
    public String selfEvaluation2;
    public String selfEvaluation3;
    public String selfEvaluation4;
    Student s1;
    database db = new database();

    //Instructor variables
    public String courseId;
    private ArrayList<String> courses = new ArrayList<String>();
    private ArrayList<String> courseIds = new ArrayList<String>();
    
    public ArrayList<String> countcourseName;
    public ArrayList<String> countcourseInstructor;
    public ArrayList<String> counttermAndYear;
    public ArrayList<String> countinterest;
    public ArrayList<String> counttime;
    public ArrayList<String> countorganisation;
    public ArrayList<String> countencouragement;
    public ArrayList<String> countindepth;
    public ArrayList<String> countmethods;
    public ArrayList<String> countappeared;
    public ArrayList<String> countchallenges;
    public ArrayList<String> countoutbox;
    public ArrayList<String> countactive;
    public ArrayList<String> countclarity;
    public ArrayList<String> countresources;
    public ArrayList<String> countteachingComments;
    public ArrayList<String> countresourceAdmin;
    public ArrayList<String> countfbackAssessment;
    public ArrayList<String> countimprovement;
    public ArrayList<String> countadditionalComments;
    public ArrayList<String> countguidance;
    public ArrayList<String> countsupport;
    public ArrayList<String> countbbresources;
    public ArrayList<String> counttimeFrame;
    public ArrayList<String> countoutcome;
    public ArrayList<String> countconstructive;
    public ArrayList<String> countexplanation;
    public ArrayList<String> countgrading;
    public ArrayList<String> counthomeworks;
    public ArrayList<String> countrecommendation;
    public ArrayList<String> countoutline;
    public ArrayList<String> countexams;
    public ArrayList<String> countprojects;
    public ArrayList<String> countworthness;
    public ArrayList<String> countexperience;
    public ArrayList<String> countoverallExperience;
    public ArrayList<String> countselfEvaluation;
    public ArrayList<String> countteachingassessment;
    public ArrayList<String> countselfEvaluation1;
    public ArrayList<String> countselfEvaluation2;
    public ArrayList<String> countselfEvaluation3;
    public ArrayList<String> countselfEvaluation4;

    public ArrayList<String> getCountcourseName() {
        return countcourseName;
    }

    public void setCountcourseName(ArrayList<String> countcourseName) {
        this.countcourseName = countcourseName;
    }

    public ArrayList<String> getCountcourseInstructor() {
        return countcourseInstructor;
    }

    public void setCountcourseInstructor(ArrayList<String> countcourseInstructor) {
        this.countcourseInstructor = countcourseInstructor;
    }

    public ArrayList<String> getCounttermAndYear() {
        return counttermAndYear;
    }

    public void setCounttermAndYear(ArrayList<String> counttermAndYear) {
        this.counttermAndYear = counttermAndYear;
    }

    public ArrayList<String> getCountinterest() {
        return countinterest;
    }

    public void setCountinterest(ArrayList<String> countinterest) {
        this.countinterest = countinterest;
    }

    public ArrayList<String> getCounttime() {
        return counttime;
    }

    public void setCounttime(ArrayList<String> counttime) {
        this.counttime = counttime;
    }

    public ArrayList<String> getCountorganisation() {
        return countorganisation;
    }

    public void setCountorganisation(ArrayList<String> countorganisation) {
        this.countorganisation = countorganisation;
    }

    public ArrayList<String> getCountencouragement() {
        return countencouragement;
    }

    public void setCountencouragement(ArrayList<String> countencouragement) {
        this.countencouragement = countencouragement;
    }

    public ArrayList<String> getCountindepth() {
        return countindepth;
    }

    public void setCountindepth(ArrayList<String> countindepth) {
        this.countindepth = countindepth;
    }

    public ArrayList<String> getCountmethods() {
        return countmethods;
    }

    public void setCountmethods(ArrayList<String> countmethods) {
        this.countmethods = countmethods;
    }

    public ArrayList<String> getCountappeared() {
        return countappeared;
    }

    public void setCountappeared(ArrayList<String> countappeared) {
        this.countappeared = countappeared;
    }

    public ArrayList<String> getCountchallenges() {
        return countchallenges;
    }

    public void setCountchallenges(ArrayList<String> countchallenges) {
        this.countchallenges = countchallenges;
    }

    public ArrayList<String> getCountoutbox() {
        return countoutbox;
    }

    public void setCountoutbox(ArrayList<String> countoutbox) {
        this.countoutbox = countoutbox;
    }

    public ArrayList<String> getCountactive() {
        return countactive;
    }

    public void setCountactive(ArrayList<String> countactive) {
        this.countactive = countactive;
    }

    public ArrayList<String> getCountclarity() {
        return countclarity;
    }

    public void setCountclarity(ArrayList<String> countclarity) {
        this.countclarity = countclarity;
    }

    public ArrayList<String> getCountresources() {
        return countresources;
    }

    public void setCountresources(ArrayList<String> countresources) {
        this.countresources = countresources;
    }

    public ArrayList<String> getCountteachingComments() {
        return countteachingComments;
    }

    public void setCountteachingComments(ArrayList<String> countteachingComments) {
        this.countteachingComments = countteachingComments;
    }

    public ArrayList<String> getCountresourceAdmin() {
        return countresourceAdmin;
    }

    public void setCountresourceAdmin(ArrayList<String> countresourceAdmin) {
        this.countresourceAdmin = countresourceAdmin;
    }

    public ArrayList<String> getCountfbackAssessment() {
        return countfbackAssessment;
    }

    public void setCountfbackAssessment(ArrayList<String> countfbackAssessment) {
        this.countfbackAssessment = countfbackAssessment;
    }

    public ArrayList<String> getCountimprovement() {
        return countimprovement;
    }

    public void setCountimprovement(ArrayList<String> countimprovement) {
        this.countimprovement = countimprovement;
    }

    public ArrayList<String> getCountadditionalComments() {
        return countadditionalComments;
    }

    public void setCountadditionalComments(ArrayList<String> countadditionalComments) {
        this.countadditionalComments = countadditionalComments;
    }

    public ArrayList<String> getCountguidance() {
        return countguidance;
    }

    public void setCountguidance(ArrayList<String> countguidance) {
        this.countguidance = countguidance;
    }

    public ArrayList<String> getCountsupport() {
        return countsupport;
    }

    public void setCountsupport(ArrayList<String> countsupport) {
        this.countsupport = countsupport;
    }

    public ArrayList<String> getCountbbresources() {
        return countbbresources;
    }

    public void setCountbbresources(ArrayList<String> countbbresources) {
        this.countbbresources = countbbresources;
    }

    public ArrayList<String> getCounttimeFrame() {
        return counttimeFrame;
    }

    public void setCounttimeFrame(ArrayList<String> counttimeFrame) {
        this.counttimeFrame = counttimeFrame;
    }

    public ArrayList<String> getCountoutcome() {
        return countoutcome;
    }

    public void setCountoutcome(ArrayList<String> countoutcome) {
        this.countoutcome = countoutcome;
    }

    public ArrayList<String> getCountconstructive() {
        return countconstructive;
    }

    public void setCountconstructive(ArrayList<String> countconstructive) {
        this.countconstructive = countconstructive;
    }

    public ArrayList<String> getCountexplanation() {
        return countexplanation;
    }

    public void setCountexplanation(ArrayList<String> countexplanation) {
        this.countexplanation = countexplanation;
    }

    public ArrayList<String> getCountgrading() {
        return countgrading;
    }

    public void setCountgrading(ArrayList<String> countgrading) {
        this.countgrading = countgrading;
    }

    public ArrayList<String> getCounthomeworks() {
        return counthomeworks;
    }

    public void setCounthomeworks(ArrayList<String> counthomeworks) {
        this.counthomeworks = counthomeworks;
    }

    public ArrayList<String> getCountrecommendation() {
        return countrecommendation;
    }

    public void setCountrecommendation(ArrayList<String> countrecommendation) {
        this.countrecommendation = countrecommendation;
    }

    public ArrayList<String> getCountoutline() {
        return countoutline;
    }

    public void setCountoutline(ArrayList<String> countoutline) {
        this.countoutline = countoutline;
    }

    public ArrayList<String> getCountexams() {
        return countexams;
    }

    public void setCountexams(ArrayList<String> countexams) {
        this.countexams = countexams;
    }

    public ArrayList<String> getCountprojects() {
        return countprojects;
    }

    public void setCountprojects(ArrayList<String> countprojects) {
        this.countprojects = countprojects;
    }

    public ArrayList<String> getCountworthness() {
        return countworthness;
    }

    public void setCountworthness(ArrayList<String> countworthness) {
        this.countworthness = countworthness;
    }

    public ArrayList<String> getCountexperience() {
        return countexperience;
    }

    public void setCountexperience(ArrayList<String> countexperience) {
        this.countexperience = countexperience;
    }

    public ArrayList<String> getCountoverallExperience() {
        return countoverallExperience;
    }

    public void setCountoverallExperience(ArrayList<String> countoverallExperience) {
        this.countoverallExperience = countoverallExperience;
    }

    public ArrayList<String> getCountselfEvaluation() {
        return countselfEvaluation;
    }

    public void setCountselfEvaluation(ArrayList<String> countselfEvaluation) {
        this.countselfEvaluation = countselfEvaluation;
    }

    public ArrayList<String> getCountteachingassessment() {
        return countteachingassessment;
    }

    public void setCountteachingassessment(ArrayList<String> countteachingassessment) {
        this.countteachingassessment = countteachingassessment;
    }

    public ArrayList<String> getCountselfEvaluation1() {
        return countselfEvaluation1;
    }

    public void setCountselfEvaluation1(ArrayList<String> countselfEvaluation1) {
        this.countselfEvaluation1 = countselfEvaluation1;
    }

    public ArrayList<String> getCountselfEvaluation2() {
        return countselfEvaluation2;
    }

    public void setCountselfEvaluation2(ArrayList<String> countselfEvaluation2) {
        this.countselfEvaluation2 = countselfEvaluation2;
    }

    public ArrayList<String> getCountselfEvaluation3() {
        return countselfEvaluation3;
    }

    public void setCountselfEvaluation3(ArrayList<String> countselfEvaluation3) {
        this.countselfEvaluation3 = countselfEvaluation3;
    }

    public ArrayList<String> getCountselfEvaluation4() {
        return countselfEvaluation4;
    }

    public void setCountselfEvaluation4(ArrayList<String> countselfEvaluation4) {
        this.countselfEvaluation4 = countselfEvaluation4;
    }
    
    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public ArrayList<String> getCourseIds() {
        return courseIds;
    }

    public void setCourseIds(ArrayList<String> courseIds) {
        this.courseIds = courseIds;
    }
    public ArrayList<String> getCourses() {
        return courses;
    }

    public void setCourses(ArrayList<String> courses) {
        this.courses = courses;
    }
    public Student() {
       courses = db.get_courses();
       courseIds = db.get_courseIds();
    }
    ////////////////////
    public void setSelfEvaluation1(String selfEvaluation1) {
        this.selfEvaluation1 = selfEvaluation1;
    }
    public String getSelfEvaluation1() {
        return selfEvaluation1;
    }
    public String getSelfEvaluation2() {
        return selfEvaluation2;
    }

    public void setSelfEvaluation2(String selfEvaluation2) {
        this.selfEvaluation2 = selfEvaluation2;
    }

    public String getSelfEvaluation3() {
        return selfEvaluation3;
    }

    public void setSelfEvaluation3(String selfEvaluation3) {
        this.selfEvaluation3 = selfEvaluation3;
    }

    public String getSelfEvaluation4() {
        return selfEvaluation4;
    }

    public void setSelfEvaluation4(String selfEvaluation4) {
        this.selfEvaluation4 = selfEvaluation4;
    }
            
    public String getTeachingassessment() {
        return teachingassessment;
    }

    public void setTeachingassessment(String teachingassessment) {
        this.teachingassessment = teachingassessment;
    }

    public String getOverallExperience() {
        return overallExperience;
    }

    public void setOverallExperience(String overallExperience) {
        this.overallExperience = overallExperience;
    }

    public String getSelfEvaluation() {
        return selfEvaluation;
    }

    public void setSelfEvaluation(String selfEvaluation) {
        this.selfEvaluation = selfEvaluation;
    }
    
    public String getTeachingComments() {
        return teachingComments;
    }

    public String getOutcome() {
        return outcome;
    }

    public void setOutcome(String outcome) {
        this.outcome = outcome;
    }

    public String getConstructive() {
        return constructive;
    }

    public void setConstructive(String constructive) {
        this.constructive = constructive;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public String getGrading() {
        return grading;
    }

    public void setGrading(String grading) {
        this.grading = grading;
    }

    public String getHomeworks() {
        return homeworks;
    }

    public void setHomeworks(String homeworks) {
        this.homeworks = homeworks;
    }

    public String getRecommendation() {
        return recommendation;
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }

    public String getOutline() {
        return outline;
    }

    public void setOutline(String outline) {
        this.outline = outline;
    }

    public String getExams() {
        return exams;
    }

    public void setExams(String exams) {
        this.exams = exams;
    }

    public String getProjects() {
        return projects;
    }

    public void setProjects(String projects) {
        this.projects = projects;
    }

    public String getWorthness() {
        return worthness;
    }

    public void setWorthness(String worthness) {
        this.worthness = worthness;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public void setTeachingComments(String teachingComments) {
        this.teachingComments = teachingComments;
    }

    public String getResourceAdmin() {
        return resourceAdmin;
    }

    public void setResourceAdmin(String resourceAdmin) {
        this.resourceAdmin = resourceAdmin;
    }

    public String getFbackAssessment() {
        return fbackAssessment;
    }

    public void setFbackAssessment(String fbackAssessment) {
        this.fbackAssessment = fbackAssessment;
    }

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }

    public String getBbresources() {
        return bbresources;
    }

    public void setBbresources(String bbresources) {
        this.bbresources = bbresources;
    }
    
    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseInstructor() {
        return courseInstructor;
    }

    public void setCourseInstructor(String courseInstructor) {
        this.courseInstructor = courseInstructor;
    }

    public String getTermAndYear() {
        return termAndYear;
    }

    public void setTermAndYear(String termAndYear) {
        this.termAndYear = termAndYear;
    }

    public String getClarity() {
        return clarity;
    }

    public void setClarity(String clarity) {
        this.clarity = clarity;
    }

    public String getResources() {
        return resources;
    }

    public void setResources(String resources) {
        this.resources = resources;
    }

    public String getGuidance() {
        return guidance;
    }

    public void setGuidance(String guidance) {
        this.guidance = guidance;
    }

    public String getImprovement() {
        return improvement;
    }

    public void setImprovement(String improvement) {
        this.improvement = improvement;
    }

    public String getTimeFrame() {
        return timeFrame;
    }

    public void setTimeFrame(String timeFrame) {
        this.timeFrame = timeFrame;
    }

    public String getSupport() {
        return support;
    }

    public void setSupport(String support) {
        this.support = support;
    }
  
    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getOrganisation() {
        return organisation;
    }

    public void setOrganisation(String organisation) {
        this.organisation = organisation;
    }

    public String getEncouragement() {
        return encouragement;
    }

    public void setEncouragement(String encouragement) {
        this.encouragement = encouragement;
    }

    public String getIndepth() {
        return indepth;
    }

    public void setIndepth(String indepth) {
        this.indepth = indepth;
    }

    public String getMethods() {
        return methods;
    }

    public void setMethods(String methods) {
        this.methods = methods;
    }

    public String getAppeared() {
        return appeared;
    }

    public void setAppeared(String appeared) {
        this.appeared = appeared;
    }

    public String getChallenges() {
        return challenges;
    }

    public void setChallenges(String challenges) {
        this.challenges = challenges;
    }

    public String getOutbox() {
        return outbox;
    }

    public void setOutbox(String outbox) {
        this.outbox = outbox;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }
      
    public Student(String userName, String passWord) {
        this.userName = userName;
        this.passWord = passWord;
    }

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }
    public String summaryPage(){
        Student s = new Student();
        s. courseName = courseName;
        s. courseInstructor = courseInstructor;
        s. termAndYear = termAndYear;
        s. interest= interest;
        s. time= time ;
        s. organisation=organisation ;
        s. encouragement= encouragement;
        s. indepth=indepth ;
        s. appeared=appeared ;
        s. methods= methods;
        s. challenges=challenges ;
        s. outbox=outbox ;
        s. active=active ;
        s. teachingComments=teachingComments ;
        s. clarity=clarity ;
        s. improvement=improvement ;
        s. timeFrame=timeFrame ;
        s. teachingassessment = teachingassessment;
        s. support=support ;
        s. bbresources=bbresources ;
        s. guidance= guidance ;
        s. resourceAdmin = resourceAdmin;
        s. explanation=explanation ;
        s. outline = outline;
        s. grading=grading ;
        s. exams=exams ;
        s. projects= projects ;
        s.additionalComments = additionalComments;
        s. worthness = worthness;
        s. recommendation=recommendation ;
        s. experience=experience ;
        s. homeworks= homeworks ;
        s.overallExperience = overallExperience;
        s. constructive=constructive ;
        s. outcome= outcome ;
        s.selfEvaluation  = selfEvaluation;
        s.selfEvaluation1 = selfEvaluation1;
        s.selfEvaluation2 = selfEvaluation2;
        s.selfEvaluation3 = selfEvaluation3;
        s.selfEvaluation4 = selfEvaluation4;
        s.courseId = courseId;

        
        try {
            db.courseDetails(s);
            db.instructorDetails(s);
            db.teachingAproachAction(s);
            db.FeedbackAssessmentAction(s);
            db.ResourceAndAdministrationAction(s);
            db.AditionalQuestionsAction(s);
            db.OverallExperienceAction(s);
            db.StrengthAndImprovementAction(s);
            db.StudentSelfEvaluationAction(s);
            db.surveyTabletid(s);
            db.surveyTableaAndqId(s);
            db.surveyTablesAndsAndeId(s);
            db.surveyTablefAndAId(s);
            db.surveyTableoAndeId(s);
            db.surveyTablerAndAId(s);
            db.surveyTablesAndiId(s);
        }
        catch (SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Summary";
    }
        public void GetSurveyPage(){
         countinterest = db.surveyAverageinterest();
         counttime = db.surveyAveragetime();
         countorganisation = db.surveyAverageorganisation();
         countencouragement = db.surveyAverageencouragement();
         countindepth = db.surveyAverageindepth();
         countappeared = db.surveyAverageappeared();
         countmethods = db.surveyAveragemethods();
         countchallenges = db.surveyAveragechallenges();
         countoutbox = db.surveyAverageoutbox();
         countactive = db.surveyAverageactive(); 
         countclarity = db.surveyAverageclarity();
         counttimeFrame = db.surveyAveragetimeFrame();
         countimprovement= db.surveyAverageimprovement();
         countteachingassessment = db.surveyAverageteachingassessment();
         countsupport = db.surveyAveragesupport();
         countbbresources = db.surveyAveragebbresources();
         countguidance = db.surveyAverageguidance();
         countresourceAdmin = db.surveyAverageresourceAdmin();
         countexplanation= db.surveyAverageexplanation();
         countoutline = db.surveyAverageoutline();
         countgrading = db.surveyAveragegrading();
         countexams = db.surveyAverageexams();
         countprojects = db.surveyAverageprojects();
         countadditionalComments = db.surveyAverageadditionalcomments();
         countworthness= db.surveyAverageworthness();
         countrecommendation = db.surveyAveragerecommendation();  
         countexperience = db.surveyAverageexperience();
         counthomeworks = db.surveyAveragehomeworks();
         countoverallExperience=db.surveyAverageoverallExperience();
         countconstructive = db.surveyAverageconstructive();
         countoutcome=db.surveyAverageoveralloutcome();
         countselfEvaluation= db.surveyAverageselfEvaluation();
         countselfEvaluation1= db.surveyAverageselfEvaluation1();
         countselfEvaluation2=db.surveyAverageselfEvaluation2();
         countselfEvaluation3= db.surveyAverageselfEvaluation3();
         countselfEvaluation4=db.surveyAverageselfEvaluation4();

        System.out.print("interest array in student is"+countinterest);
        
        }
}
